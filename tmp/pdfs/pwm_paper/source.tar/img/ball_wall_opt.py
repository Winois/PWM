import torch
from torch.distributions.normal import Normal
from torch.autograd import Variable
from torch.func import vmap, grad
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import seaborn as sns
from tqdm import tqdm
import numpy as np
import scipy.integrate as integrate

sns.set()
torch.manual_seed(0)


g, h, w = -9.81, 0.0, 10


def f(x, v, th, a, t):
    ty = (-v * torch.cos(th) + (v**2 * torch.cos(th) ** 2 + a * w) ** 0.5) / a
    y = v * torch.sin(th) * ty + g / 2 * ty**2
    out = x + v * torch.cos(th) * t + 1 / 2 * a * t**2
    out = torch.where((h > y) & (ty < t), w, out)
    return out


def f_grad(x, v, th, a, t, std):
    vals = np.empty_like(th)
    for i in range(len(th)):
        vals[i] = (
            v * t / 2**0.5 / 4 * np.exp(-(std**2) / 4) * np.sin(th[i])
            - integrate.quad(
                lambda w: np.exp(-(w**2) / std**2) * np.cos(th[i] + w), -1.418, 0.248
            )[0]
        )

    return vals


fig, ax = plt.subplots(1, 4, figsize=(12, 3), sharey=True)
ax = ax.flatten()

# simulation variables
x, v, a, t = 0, 10, 1, 2
std = 0.1  # noise for policy
iters = 300  # for optimization
lr = 5e-2
init_th = -3.0
stds = torch.Tensor([0.01, 0.1, 0.25, 1.0])
ns = [1, 10, 50, 10000]
styles = ["-", "--", "-.", ":"]


for i, n in enumerate(ns):

    ###########################################################################
    print(f"Policy gradients optimization; N={n}")

    for k, std in tqdm(enumerate(stds)):
        losses = []
        mu = Variable(torch.Tensor([init_th]), requires_grad=True)
        opt = torch.optim.Adam([mu], lr=lr)
        for j in range(iters):
            opt.zero_grad()
            pi = Normal(mu, std)
            act = pi.sample((n, 1))
            y = -f(x, v, act, a, t).detach()
            y = y - y.mean()
            logp = pi.log_prob(act)
            loss = torch.mean(y * logp)
            loss.backward()
            losses.append(-f(x, v, mu, a, t).item())
            opt.step()

        ax[k].plot(losses, styles[i], label="PG", color="tab:blue")

    ##########################################################################
    print(f"First-order gradients optimization; N={n}")

    for k, std in tqdm(enumerate(stds)):
        losses = []
        mu = Variable(torch.Tensor([init_th]), requires_grad=True)
        opt = torch.optim.Adam([mu], lr=lr)
        for j in range(iters):
            opt.zero_grad()
            pi = Normal(mu, std)
            act = pi.rsample((n, 1))
            (-f(x, v, act, a, t)).mean().backward()
            opt.step()
            losses.append(-f(x, v, mu, a, t).item())
        ax[k].plot(losses, styles[i], label=f"FO", color="tab:orange")

    custom_lines = [
        Line2D([0], [0], color="tab:blue", lw=2),
        Line2D([0], [0], color="tab:orange", lw=2),
    ]

    ax[i].legend(custom_lines, ["PG", "FO"])
    ax[i].set_title(f"N={n}")
    ax[i].set_ylabel("$J(\\theta)$")
    ax[i].set_xlabel("Iterations")

plt.tight_layout()
plt.savefig(f"ball_wall_opt.pdf", bbox_inches="tight")
plt.show()
